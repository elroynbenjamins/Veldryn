import { normalizeRecruitmentDescription, type PartyActivityPreference, type PartyPlayStyle } from '../party/party-policy';

export const RECRUITMENT_POST_TTL_HOURS = 24;
export const GUILD_SEEKER_DESCRIPTION_MAX = 220;

export type PartyGoalTag =
  | 'weekly_contracts'
  | 'combat'
  | 'bosses'
  | 'skilling'
  | 'gathering'
  | 'crafting'
  | 'party_events'
  | 'dungeons'
  | 'social';

export type GuildFocusTag =
  | 'social'
  | 'pve'
  | 'skilling'
  | 'progression'
  | 'collections'
  | 'events'
  | 'competitive'
  | 'new_player_friendly';

export interface PartyRecruitmentPost {
  kind: 'party_lfm';
  partyId: string;
  ownerAccountId: string;
  activityPreference: PartyActivityPreference;
  playStyle: PartyPlayStyle;
  goalTags: readonly PartyGoalTag[];
  description: string;
  memberCount: number;
  maxMembers: 4;
}

export interface PlayerPartySeekerPost {
  kind: 'player_lfg';
  accountId: string;
  characterId: string;
  activityPreference: PartyActivityPreference;
  playStyle: PartyPlayStyle;
  goalTags: readonly PartyGoalTag[];
  description: string;
  classId?: string;
  combatLevel?: number;
}

export interface GuildRecruitmentProfile {
  kind: 'guild_lfm';
  guildId: string;
  ownerAccountId: string;
  focusTags: readonly GuildFocusTag[];
  playStyle: PartyPlayStyle;
  description: string;
  memberCount: number;
  memberCap: number;
}

export interface PlayerGuildSeekerPost {
  kind: 'player_guild_lfg';
  accountId: string;
  characterId: string;
  desiredFocusTags: readonly GuildFocusTag[];
  playStyle: PartyPlayStyle;
  description: string;
  classId?: string;
  combatLevel?: number;
}

export interface RecruitmentCompatibility {
  score: number;
  reasons: string[];
}

function overlap<T extends string>(a: readonly T[], b: readonly T[]): T[] {
  const bSet = new Set(b);
  return a.filter((value) => bSet.has(value));
}

function playStyleScore(a: PartyPlayStyle, b: PartyPlayStyle): number {
  if (a === b) return 20;
  const order: PartyPlayStyle[] = ['casual', 'balanced', 'active', 'competitive'];
  const distance = Math.abs(order.indexOf(a) - order.indexOf(b));
  return distance === 1 ? 12 : distance === 2 ? 5 : 0;
}

function activityPreferenceScore(a: PartyActivityPreference, b: PartyActivityPreference): number {
  if (a === b) return 45;
  if (a === 'mixed' || b === 'mixed') return 30;
  return 5;
}

export function normalizePartyRecruitmentPost(post: PartyRecruitmentPost): PartyRecruitmentPost {
  return {
    ...post,
    goalTags: [...new Set(post.goalTags)].slice(0, 6),
    description: normalizeRecruitmentDescription(post.description),
  };
}

export function normalizePlayerPartySeekerPost(post: PlayerPartySeekerPost): PlayerPartySeekerPost {
  return {
    ...post,
    goalTags: [...new Set(post.goalTags)].slice(0, 6),
    description: normalizeRecruitmentDescription(post.description),
  };
}

export function normalizeGuildSeekerDescription(description: string): string {
  return description.replace(/\s+/g, ' ').trim().slice(0, GUILD_SEEKER_DESCRIPTION_MAX);
}

export function scorePartyCompatibility(
  seeker: PlayerPartySeekerPost,
  party: PartyRecruitmentPost,
): RecruitmentCompatibility {
  const reasons: string[] = [];
  let score = 0;
  const activity = activityPreferenceScore(seeker.activityPreference, party.activityPreference);
  score += activity;
  if (activity >= 30) reasons.push('activity_match');

  const style = playStyleScore(seeker.playStyle, party.playStyle);
  score += style;
  if (style >= 12) reasons.push('play_style_match');

  const sharedGoals = overlap(seeker.goalTags, party.goalTags);
  const goalScore = Math.min(30, sharedGoals.length * 10);
  score += goalScore;
  if (sharedGoals.length > 0) reasons.push('shared_goals');

  if (party.memberCount < party.maxMembers) {
    score += 5;
    reasons.push('space_available');
  }

  return { score: Math.min(100, score), reasons };
}

export function scoreGuildCompatibility(
  seeker: PlayerGuildSeekerPost,
  guild: GuildRecruitmentProfile,
): RecruitmentCompatibility {
  const reasons: string[] = [];
  let score = playStyleScore(seeker.playStyle, guild.playStyle);
  if (score >= 12) reasons.push('play_style_match');
  const sharedFocus = overlap(seeker.desiredFocusTags, guild.focusTags);
  score += Math.min(65, sharedFocus.length * 18);
  if (sharedFocus.length > 0) reasons.push('shared_focus');
  if (guild.memberCount < guild.memberCap) {
    score += 15;
    reasons.push('space_available');
  }
  return { score: Math.min(100, score), reasons };
}

export function sortPartyMatches(
  seeker: PlayerPartySeekerPost,
  parties: readonly PartyRecruitmentPost[],
): PartyRecruitmentPost[] {
  return [...parties]
    .filter((party) => party.memberCount < party.maxMembers)
    .sort((a, b) => scorePartyCompatibility(seeker, b).score - scorePartyCompatibility(seeker, a).score);
}

export function sortGuildMatches(
  seeker: PlayerGuildSeekerPost,
  guilds: readonly GuildRecruitmentProfile[],
): GuildRecruitmentProfile[] {
  return [...guilds]
    .filter((guild) => guild.memberCount < guild.memberCap)
    .sort((a, b) => scoreGuildCompatibility(seeker, b).score - scoreGuildCompatibility(seeker, a).score);
}
