import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import type { GuildRecruitmentCard, GuildSeekerCard, PartyContractView, PartyRecruitmentCard, PartySeekerCard, PartyView } from '../core/party-social';
import { GuildSeekerPanel } from './GuildSeekerPanel';
import { PartyHubPanel } from './PartyHubPanel';
import { RecruitmentBoardPanel } from './RecruitmentBoardPanel';

type SocialSection = 'party' | 'party_find' | 'guild_find';

export interface SocialHubPanelProps {
  party: PartyView | null;
  contracts: PartyContractView[];
  partyListings: PartyRecruitmentCard[];
  partySeekers: PartySeekerCard[];
  guildListings: GuildRecruitmentCard[];
  guildSeekers: GuildSeekerCard[];
  canManageParty: boolean;
  callbacks?: Record<string, (...args: any[]) => void>;
}

/**
 * Integration component for the existing VELDRYN Social/Account surface.
 * Codex should wire these callbacks to the repository's existing navigation and online client instead of creating a sixth bottom tab.
 */
export function SocialHubPanel(props: SocialHubPanelProps) {
  const [section, setSection] = useState<SocialSection>('party');
  const cb = props.callbacks ?? {};
  return (
    <View style={styles.wrap}>
      <View style={styles.switcher}>
        <Pressable style={[styles.switch, section === 'party' && styles.active]} onPress={() => setSection('party')}><Text style={styles.text}>Party</Text></Pressable>
        <Pressable style={[styles.switch, section === 'party_find' && styles.active]} onPress={() => setSection('party_find')}><Text style={styles.text}>LFG</Text></Pressable>
        <Pressable style={[styles.switch, section === 'guild_find' && styles.active]} onPress={() => setSection('guild_find')}><Text style={styles.text}>Guilds</Text></Pressable>
      </View>
      {section === 'party' && <PartyHubPanel party={props.party} contracts={props.contracts} canManageParty={props.canManageParty} onFindParty={() => setSection('party_find')} onOpenRecruitmentBoard={() => setSection('party_find')} onCreateParty={cb.onCreateParty as any} onOpenPartyChat={cb.onOpenPartyChat as any} onToggleRecruitment={cb.onToggleRecruitment as any} onAcceptContract={cb.onAcceptContract as any} onClaimContract={cb.onClaimContract as any} onLeaveParty={cb.onLeaveParty as any} />}
      {section === 'party_find' && <RecruitmentBoardPanel parties={props.partyListings} players={props.partySeekers} onRequestJoin={cb.onRequestJoin as any} onInvitePlayer={cb.onInvitePlayer as any} onCreatePlayerPost={cb.onCreatePlayerPost as any} onCreatePartyPost={cb.onCreatePartyPost as any} />}
      {section === 'guild_find' && <GuildSeekerPanel guilds={props.guildListings} seekers={props.guildSeekers} onApply={cb.onApplyGuild as any} onInviteToGuild={cb.onInviteToGuild as any} onAdvertiseSelf={cb.onAdvertiseSelfForGuild as any} onEditGuildRecruitment={cb.onEditGuildRecruitment as any} />}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: 10 },
  switcher: { flexDirection: 'row', gap: 6 },
  switch: { flex: 1, alignItems: 'center', paddingVertical: 8, borderRadius: 8, backgroundColor: '#16232e', borderWidth: 1, borderColor: '#304355' },
  active: { backgroundColor: '#29251c', borderColor: '#bc9649' },
  text: { color: '#d0dbe3', fontWeight: '900', fontSize: 12 },
});
