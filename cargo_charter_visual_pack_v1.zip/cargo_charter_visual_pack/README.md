# Cargo Charter / Logistics District Visual Pack

This pack contains the generated Cargo Charter artwork as **individual transparent PNG sprites** plus the original source sheets.

## Recommended repo target

Copy:

`assets/logistics/`

into the game's asset tree, preserving the subfolders:

- `buildings/`
- `tiles/`
- `vehicles/`
- `props/`

The exact repo path can be adjusted to your existing asset conventions.

## Core map layout

Recommended first layout:

`Main Airport -> Logistics Gate -> Service Road -> Cargo District`

The district centers around `cargo_aircraft_stand.png`, with the Cargo Warehouse / Cargo Charter Office nearby.

## Cargo Charter visual states

1. **No active charter:** apron is empty.
2. **Charter active:** show `cargo_aircraft_twin_prop.png` on the cargo stand.
3. **Crates filled:** progressively spawn wrapped-pallet / cargo props beside the aircraft.
4. **Ready:** all four crates visible and the Send Charter action becomes prominent.
5. **Departed:** remove the aircraft and staged cargo, then return to the empty-stand state.

## Placement

All production/storage/cargo district content should use the `LOGISTICS` placement zone.
Recommended map-sprite pivot is **bottom-center** with normal isometric depth sorting.

## Important

The generated building/vehicle art is ready for wiring, but exact gameplay footprints and sprite offsets should be tuned against the game's existing 64x32 logical tile grid rather than inferred only from image pixels.

See `cargo_charter_asset_manifest.json` for suggested roles and initial footprints.
