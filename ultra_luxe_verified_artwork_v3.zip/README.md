VELDRYN / Ultra Luxe verified runtime artwork v3
Base: PR #1724, commit 4f4ed07e33da3661ba02dece66fb68074e945651 or descendant.
All WebPs decoded with Pillow, RIFF/chunk lengths checked and SHA-256 manifest generated.
Artwork only; no production grant, no changes to release flags.
Do not use older six-pose atlases. New Aetherion 8x6 (112x159) and Vharaxis 6x6 (128x120), 12fps.
On the draft checkout: verify the manifest, copy only apps/mobile/assets/... files, then replace draconic-integration-assets.ts with provided registry. In celestial-integration-assets.ts add smoothPoseAtlas:require('../../assets/ascendant/celestial/aetherion_smooth_pose_atlas.webp'), to scene. In profile-border-assets.ts replace the interim celestial.scene.border expression (including comment) with require('../../assets/ascendant/celestial/celestial_border_standard.webp') as ImageSourcePropType. Check the repository diff before committing and run mobile UX and native validation. Server grant authority still pending.
