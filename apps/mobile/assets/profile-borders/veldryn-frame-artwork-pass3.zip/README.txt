Upload ONLY the three WebP files into apps/mobile/assets/profile-borders/ on chatgpt/standard-frame-artwork-v2. Do not overwrite existing dungeon rewards. Native QA is required before merging.
