# VELDRYN v16.1 — Parties, Party Contracts & Recruitment

This ZIP is a **merge pack for Codex**, not a replacement repository.

The working VELDRYN repository is newer than the supplied `veldryn_backend_v2.1` foundation, so Codex must inspect the real repository first and merge these files into the current architecture instead of copying an old project tree over newer work.

## What this pass implements

- Persistent **1–4 player Parties**.
- Base Party Mode has **no Tank / Damage / Support composition requirement**.
- Existing Live Dungeons keep their separate strict **1 Tank / 2 Damage / 1 Support** rule.
- Party invites, join requests, leave/leader-transfer domain logic.
- Party Chat availability while the player belongs to a persistent Party.
- Weekly rotation containing exactly:
  - one Combat Party Contract,
  - one Skilling Party Contract,
  - one Mixed Party Contract.
- One Party Contract active at a time per Party; complete it, then the Party may activate another weekly option.
- Contribution points normalized by **expected server-owned activity time + challenge**, not raw click/action counts.
- Offline/idle progress can contribute, but contract credit has a daily cap.
- Anti-carry / anti-leech rules with meaningful personal contribution requirements.
- Party-event ranking persistence hooks.
- Two-sided Party recruitment:
  - **Party LF Members** posts.
  - **Player LFG** self-advertisements.
- Two-sided Guild recruitment:
  - guild recruitment profiles,
  - **Player Looking for Guild** self-advertisements with short description and desired guild focus.
- Mobile-first Party, LFG and Guild recruitment panel components.
- Supabase schema/migration foundation and RLS read policies.

## Important product rule

**Do not match Parties on one exact active quest.**

Discovery uses broad activity preference:

- Combat
- Skilling
- Mixed

plus optional broad goal tags such as Bosses, Crafting, Weekly Contracts, Party Events or Dungeons.

This lets a good Party survive weekly quest rotation instead of forcing the player to rebuild a group whenever a contract changes.

## Merge order for Codex

1. Inspect the current repository and locate the latest social, friends/LFG, guild, chat, online API, activity settlement, combat settlement, idle settlement and Supabase modules.
2. Read `PARTIES_CONTRACTS_GUILD_SEEKERS_V16_1.md` completely.
3. Merge backend domain files from `files/backend/src/server/party/` and `files/backend/src/server/social/` into current equivalents.
4. Merge API contract names only where the current API/router pattern requires them.
5. Add the new migration as a **new migration**. Do not edit previously applied migrations.
6. Wire Party contribution recording into trusted server settlement paths. Clients must never submit point totals, expected seconds, challenge multipliers or completion state.
7. Integrate mobile components into the current Social/Account UI. Do not create a sixth bottom navigation tab.
8. Reuse the current Chat overlay and expose a persistent `Party` channel only when the account is in a Party. Do not merge this with Live Dungeon run-scoped chat.
9. Run current repository tests plus the v16.1 tests and resolve integration differences without weakening assertions.
10. Report changed files and any real-database/realtime tests that still require the deployed Supabase environment.

## Verification already performed against supplied backend foundation

- TypeScript typecheck: PASS
- TypeScript build: PASS
- New Party domain tests: PASS
- New recruitment tests: PASS
- Existing production smoke: PASS
- Existing backend pass smoke: PASS
- Mobile client-safe core test: PASS

A real Supabase reset/apply was not performed in this environment. Codex should run the repository's actual database migration tests before release.
