export type PartyActivityPreference = 'combat' | 'skilling' | 'mixed';
export type PartyPlayStyle = 'casual' | 'balanced' | 'active' | 'competitive';
export type PartyGoalTag = 'weekly_contracts' | 'combat' | 'bosses' | 'skilling' | 'gathering' | 'crafting' | 'party_events' | 'dungeons' | 'social';
export type GuildFocusTag = 'social' | 'pve' | 'skilling' | 'progression' | 'collections' | 'events' | 'competitive' | 'new_player_friendly';

export interface PartyMemberView {
  accountId: string;
  characterId: string;
  displayName: string;
  className?: string;
  combatLevel?: number;
  isLeader: boolean;
  online?: boolean;
}

export interface PartyView {
  id: string;
  name: string;
  activityPreference: PartyActivityPreference;
  playStyle: PartyPlayStyle;
  members: PartyMemberView[];
  recruitmentOpen: boolean;
}

export interface PartyContractView {
  id: string;
  name: string;
  focus: PartyActivityPreference;
  description: string;
  targetPoints: number;
  totalPoints: number;
  combatPoints: number;
  skillingPoints: number;
  personalPoints: number;
  eligible: boolean;
  complete: boolean;
  expiresAt: string;
}

export interface PartyRecruitmentCard {
  id: string;
  partyName: string;
  memberCount: number;
  activityPreference: PartyActivityPreference;
  playStyle: PartyPlayStyle;
  goalTags: PartyGoalTag[];
  description: string;
  compatibilityScore?: number;
}

export interface PartySeekerCard {
  accountId: string;
  characterId: string;
  displayName: string;
  className?: string;
  combatLevel?: number;
  activityPreference: PartyActivityPreference;
  playStyle: PartyPlayStyle;
  goalTags: PartyGoalTag[];
  description: string;
}

export interface GuildRecruitmentCard {
  guildId: string;
  guildName: string;
  memberCount: number;
  memberCap: number;
  focusTags: GuildFocusTag[];
  playStyle: PartyPlayStyle;
  description: string;
  compatibilityScore?: number;
}

export interface GuildSeekerCard {
  accountId: string;
  characterId: string;
  displayName: string;
  className?: string;
  combatLevel?: number;
  desiredFocusTags: GuildFocusTag[];
  playStyle: PartyPlayStyle;
  description: string;
}

export const activityPreferenceLabel: Record<PartyActivityPreference, string> = {
  combat: 'Combat',
  skilling: 'Skilling',
  mixed: 'Mixed',
};

export const playStyleLabel: Record<PartyPlayStyle, string> = {
  casual: 'Casual',
  balanced: 'Balanced',
  active: 'Active',
  competitive: 'Competitive',
};

export function contractProgressPercent(contract: PartyContractView): number {
  if (contract.targetPoints <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round((contract.totalPoints / contract.targetPoints) * 100)));
}

export function contractEligibilityLabel(contract: PartyContractView): string {
  if (contract.eligible) return 'Reward eligible';
  if (contract.complete) return 'Contribute more to claim';
  return 'Keep contributing';
}
