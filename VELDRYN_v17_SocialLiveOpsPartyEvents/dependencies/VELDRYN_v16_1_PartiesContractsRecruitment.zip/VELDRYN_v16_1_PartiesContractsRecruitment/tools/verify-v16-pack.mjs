import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const root = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve(new URL('..', import.meta.url).pathname);
const required = [
  'START_HERE.md',
  'PARTIES_CONTRACTS_GUILD_SEEKERS_V16_1.md',
  'CODEX_INSTRUCTIONS.txt',
  'files/backend/src/server/party/party-policy.ts',
  'files/backend/src/server/party/party-contracts.ts',
  'files/backend/src/server/party/party-contract-schedule.ts',
  'files/backend/src/server/party/party-service.ts',
  'files/backend/src/server/party/party-contract-service.ts',
  'files/backend/src/server/party/__tests__/party-v16.ts',
  'files/backend/src/server/social/recruitment.ts',
  'files/backend/src/server/social/recruitment-ui.ts',
  'files/backend/src/server/social/recruitment.test.ts',
  'files/backend/src/server/api/contracts.ts',
  'files/backend/supabase/migrations/20260913_025_parties_contracts_recruitment_v16_1.sql',
  'files/apps/mobile/src/core/party-social.ts',
  'files/apps/mobile/src/online/social-v16.ts',
  'files/apps/mobile/src/components/PartyHubPanel.tsx',
  'files/apps/mobile/src/components/RecruitmentBoardPanel.tsx',
  'files/apps/mobile/src/components/GuildSeekerPanel.tsx',
  'files/apps/mobile/src/components/PartyChatGate.tsx',
  'files/apps/mobile/src/components/SocialHubPanel.tsx',
  'files/apps/mobile/tests/party-social-v16.ts',
];
for (const rel of required) {
  if (!fs.existsSync(path.join(root, rel))) throw new Error(`Missing required file: ${rel}`);
}
const migration = fs.readFileSync(path.join(root, 'files/backend/supabase/migrations/20260913_025_parties_contracts_recruitment_v16_1.sql'), 'utf8');
const migrationChecks = [
  'party_recruitment_posts',
  'party_seeker_posts',
  'guild_seeker_posts',
  'party_contract_instances',
  'party_contract_contribution_receipts',
  'party_weekly_social_goal_claims',
  'party_event_scores',
  "where status='active'",
  'enable row level security',
];
for (const check of migrationChecks) {
  if (!migration.includes(check)) throw new Error(`Migration static check failed: ${check}`);
}
function walk(dir) {
  const out = [];
  for (const name of fs.readdirSync(dir)) {
    const p = path.join(dir, name);
    const st = fs.statSync(p);
    if (st.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
}
const files = walk(root).filter((p) => !p.includes(`${path.sep}verification${path.sep}mobile_test_build${path.sep}`) && !p.endsWith(`${path.sep}verification${path.sep}checksums.sha256`));
const hashes = files.map((file) => ({
  path: path.relative(root, file).replaceAll(path.sep, '/'),
  sha256: crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),
})).sort((a,b) => a.path.localeCompare(b.path));
fs.writeFileSync(path.join(root, 'verification', 'checksums.sha256'), hashes.map((x) => `${x.sha256}  ${x.path}`).join('\n') + '\n');
console.log(`verify-v16-pack ok: ${hashes.length} files; ${migrationChecks.length} migration checks`);
