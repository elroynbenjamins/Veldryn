# VELDRYN v16.1 Product + Implementation Contract

## 1. Persistent Party identity

A normal VELDRYN Party is a lightweight social group that persists while members perform normal solo/idle activities.

- Size: **1–4 players**.
- A player may create a one-person Party and recruit from there.
- A normal Party does **not** enforce combat role composition.
- Players may remain in Party while gathering, crafting, fighting, using the market, doing story content or being offline.
- Party members do not need to be online at the same time for Party Contracts.
- The Party stores a broad preferred activity style: Combat, Skilling or Mixed.
- No permanent Party level, Party skill tree or Party-only currency is introduced.

Live Dungeon matchmaking remains a separate system and keeps exactly 1 Tank / 2 Damage / 1 Support.

## 2. Recruitment and LFG

### Party → looking for members

The Party leader can open an LF Members listing while the Party has fewer than four members.

Listing fields:

- Party name.
- Current member count.
- Activity preference: Combat / Skilling / Mixed.
- Play style: Casual / Balanced / Active / Competitive.
- Broad goal tags.
- Short description.
- Optional public class/level summaries from existing profile-safe data.

Do **not** require the exact current Party Contract ID in the listing. An exact goal may be shown as optional context, but it is not the primary match key.

### Player → looking for Party

A player can advertise themselves even when they are not in a Party.

Fields:

- selected character,
- class and public level,
- Combat / Skilling / Mixed preference,
- play style,
- broad goal tags,
- short description.

Party leaders can invite directly from this board.

### Guild recruitment in both directions

Keep normal guild browsing, but add the inverse flow too:

**Player Looking for Guild**

- short description,
- selected character/class/level,
- desired guild focus tags,
- play style.

Suggested guild focus tags:

- Social
- PvE
- Skilling
- Progression
- Collections
- Events
- Competitive
- New-player friendly

Guild leaders/officers may browse seeker cards and send an invite using existing guild authority rules.

## 3. Party Contracts — weekly structure

Every real-world week has three rotating options:

1. Combat
2. Skilling
3. Mixed

A Party has **one active Party Contract at a time** to prevent overlapping contracts from double-rewarding the same underlying activity.

After completion, the Party may activate another contract from the same weekly rotation if desired.

The weekly social objective only needs **one Party Contract completion**, so players are encouraged to cooperate without turning the game into a checklist.

## 4. Difficulty target

The initial contract target is approximately **3.6–4.0 standardized Party-hours total**.

At typical contribution rates:

- 4 players: about 55–60 minutes each on average.
- 3 players: about 70–80 minutes each on average.
- 2 players: roughly 1.8–2.0 hours each on average.

This is a balance target, not a promise that every activity resolves at exactly that wall-clock time. Harder content can complete the target somewhat faster because challenge is rewarded.

## 5. Effort-based points

### Core formula

`1000 points = one standardized routine hour`.

For each authoritative activity settlement:

`points = expected_seconds × quantity / 3600 × 1000 × challenge_multiplier`

Challenge multipliers in v16.1:

- Routine: 1.00
- Demanding: 1.10
- Elite: 1.20
- Boss: 1.35

Expected seconds and challenge classification come from **server-owned content/activity data**.

Never allow a client to submit:

- expected seconds,
- challenge tier,
- point amount,
- completion state,
- reward eligibility.

### Why this is necessary

Raw counts would make fast activities disproportionately strong. For example, 500 quick mining actions should not automatically be worth more than several difficult boss kills simply because the action count is larger.

Effort normalization lets every playstyle contribute fairly:

- normal combat,
- elite combat,
- bosses,
- gathering,
- processing,
- crafting,
- eligible deliveries/contracts.

## 6. Offline contribution and anti-AFK limits

VELDRYN is an idle MMO, so offline progress is allowed to contribute.

However, a very long offline claim must not instantly finish the entire Party Contract.

Initial per-account contract credit cap:

- **1600 contribution points per UTC day**.

Raw progress may still be logged for telemetry, but only the capped amount counts toward the contract that day.

## 7. Anti-carry / anti-leech

### Single-account completion share

One account may provide at most **85%** of the contract's completion points.

This allows a very active player to carry more of the workload, but they cannot finish the entire cooperative contract alone.

### Personal reward eligibility

Full Party Contract reward eligibility requires personal raw contribution of:

- at least **6% of target**, or
- the absolute floor of **250 points**,
- whichever is higher.

For a 3600-point contract, 250 points is roughly fifteen routine standardized minutes.

### Distinct contributors

A completed Party Contract requires at least **two meaningful qualifying contributors**.

This prevents a one-player shell Party from satisfying the social system while still allowing contribution to be very uneven.

### Mixed contracts

Mixed contracts require at least **30% of the target from Combat** and **30% from Skilling**.

The remaining 40% can come from either category.

## 8. Contract reward direction

Use existing currencies/resources only.

Standard Party Contracts may grant:

- Gold,
- account/skill XP where appropriate,
- regional materials,
- crafting materials,
- Companion Essence where appropriate.

Enhanced/harder contract variants may add:

- stronger material bundles,
- a small Bondstone chance or carefully capped guarantee if compatible with the current economy,
- cosmetic/title progress.

Do not add `Party Tokens`.

## 9. Temporary Party Events

The migration includes Party-event aggregate/member-score hooks.

Short events can reuse the same authoritative effort scoring. Example categories:

- Combat event
- Skilling event
- Mixed Rift/event response

Show:

- personal contribution,
- Party contribution,
- Party rank,
- optional Friends/Guild Party rank.

High-rank reward gaps should remain small in permanent power. Top ranks should emphasize:

- titles,
- borders,
- badges,
- temporary profile trophies,
- cosmetics,
- leaderboard history.

## 10. Party Chat

Persistent Party membership exposes a normal `Party` channel in the global Chat overlay.

When the player is not in a persistent Party, that channel disappears.

Do not replace or merge the existing Live Dungeon run-specific chat. The two concepts have different lifetimes and access rules.

## 11. State / security requirements

Server owns:

- Party membership mutation,
- invitation/request acceptance,
- contract activation,
- contribution scoring,
- daily caps,
- account completion-share cap,
- completion state,
- reward eligibility,
- reward claim idempotency,
- event ranking totals.

Client sends intentions and identifiers only.

Contribution settlement must be idempotent by `source_event_id` so reconnect/retry cannot duplicate points.

Party membership is account-unique. Multiple characters from one account cannot occupy several Party slots.

## 12. Mobile UX

The included components are integration-ready presentation references, not permission to replace the current navigation architecture.

Recommended flow inside existing Account/Social surfaces:

- Party
  - Party overview
  - Contracts
  - Recruit
- Find Party / LFG
  - Parties LF Members
  - Players LFG
- Guilds
  - Guilds Recruiting
  - Players Seeking Guild

Keep touch targets large and text readable on portrait mobile screens. Preserve the current VELDRYN dark fantasy/pixel-game visual language and use existing design tokens when present.
