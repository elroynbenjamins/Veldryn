/** Opt-in native visual QA. Fixtures live only in memory; never mounts auth or save providers. */
import React,{useState} from 'react';
import {SafeAreaView,ScrollView,StyleSheet,Text,View,Pressable,StatusBar,Platform} from 'react-native';
import {newGame,createCharacter,startCombat,previewActivityReward,craftRecipe,claimActivity,stopActivity} from '../core/game';
import {HomeScreen} from '../screens/HomeScreen';
import {SkillsScreen} from '../screens/SkillsScreen';
import {SkillDashboard} from '../components/SkillDashboard';
import {BattleStage} from '../components/BattleStage';
import {BossEncounterIntro} from '../components/BossEncounterIntro';
import {PartyHubPanel} from '../components/PartyHubPanel';
import {RecruitmentListing} from '../components/RecruitmentListing';
import {PrimaryNavigation} from '../components/PrimaryNavigation';
import {GameTopBar} from '../components/GameTopBar';
import {OnlineAccountPanel} from '../components/OnlineAccountPanel';
import {AccountWelcomeScreen} from '../components/AccountWelcomeScreen';
import {STARTUP_SCENES} from '../theme/startup-art';
import {MONSTERS} from '../content/monsters';
import {ITEMS} from '../content/items';
import {RecruitmentCardView,PersistentPartySummary} from '../core/party-social';
import {C} from '../theme/theme';
const now=Date.now();
function fixture(){
 const state=createCharacter(newGame(now),'IRONWARDEN','Aster Nightfall','female');
 state.character!.gold=4500;state.character!.level=25;
 state.inventory.stacks=ITEMS.filter(i=>i.type==='material').slice(0,100).map(i=>({itemId:i.id,quantity:100}));
 state.inventory.capacity=120;
 state.skills=state.skills.map(s=>({...s,level:25,xp:4000}));
 state.settings.reduceMotion=true;
 return startCombat(state,'MOSS_RAT',now-600000);
}
const party:PersistentPartySummary={id:'qa-party',maxMembers:4,focus:'mixed',members:[
 {accountId:'qa',characterId:'qa1',characterName:'Aster Nightfall',className:'Ironwarden',role:'tank',isLeader:true},
 {accountId:'qa2',characterId:'qa2',characterName:'Longname Dawnkeeper',className:'Dawnkeeper',role:'support',isLeader:false},
 {accountId:'qa3',characterId:'qa3',characterName:'Wandering Wayfinder',className:'Wayfinder',role:'damage',isLeader:false}
]};
const post:RecruitmentCardView={id:'qa-post',postType:'party_recruiting',ownerName:'Aster Nightfall',title:'Preparing for the Fallen Knight',body:'A relaxed party for hunting, gathering, and the next Asterfall challenge.',roles:['damage','support'],focus:'mixed',activityTags:['Bosses'],playstyleTags:['Relaxed'],availabilityTags:[],guildInterestTags:[],currentObjective:'The Fallen Knight',openSpots:1,expiresAtMs:now+3600000};
const sections=['Home','Skills','Crafting','Combat','Social','Guild','Login'] as const;
type Section=typeof sections[number];
const destinations=['Character','Skills','World','Inventory','More'] as const;
export default function NativeVisualReview(){
 const [section,setSection]=useState<Section>('Home'),[state,setState]=useState(fixture),[active,setActive]=useState<typeof destinations[number]>('Character');
 const noop=()=>{};
 return <SafeAreaView style={s.root}><View style={s.qa}><Text style={s.qaLabel}>NATIVE QA · MEMORY FIXTURES</Text><ScrollView horizontal contentContainerStyle={s.selector}>{sections.map(name=><Pressable key={name} accessibilityRole="button" accessibilityLabel={'QA '+name} onPress={()=>setSection(name)} style={s.pick}><Text style={{color:section===name?C.accent:C.text}}>{name}</Text></Pressable>)}</ScrollView></View>
 <View style={s.flex}>
 {section==='Login'?<AccountWelcomeScreen scene={STARTUP_SCENES[0]}><OnlineAccountPanel state={newGame(now)}/></AccountWelcomeScreen>:<>
 <GameTopBar state={state} nowMs={now} labelForDestination={x=>x} onNavigate={noop} onChangeDestinations={noop}/>
 {section==='Home'&&<HomeScreen state={state} preview={previewActivityReward(state,now)} onClaim={()=>setState(s=>claimActivity(s,now).state)} onStop={()=>setState(stopActivity)} onNavigate={noop} onOpenCombat={()=>setSection('Combat')} onOpenSkill={()=>setSection('Skills')}/>}
 {section==='Skills'&&<ScrollView contentContainerStyle={s.content}><SkillDashboard state={state} onCombat={()=>setSection('Combat')} onSkill={noop}/></ScrollView>}
 {section==='Crafting'&&<SkillsScreen state={state} initialMode="crafting" onCraft={id=>setState(s=>craftRecipe(s,id,now))} onGather={noop} onEquipTool={noop} onCharacter={noop} onInventory={noop} onViewToolRecipes={noop}/>}
 {section==='Combat'&&<ScrollView contentContainerStyle={s.content}><BattleStage state={state} monster={MONSTERS.find(m=>m.id==='MOSS_RAT')!} elapsedSeconds={7} cycleSeconds={12}/><BossEncounterIntro monster={MONSTERS.find(m=>m.id==='FALLEN_KNIGHT')!}/></ScrollView>}
 {section==='Social'&&<ScrollView contentContainerStyle={s.content}><PartyHubPanel accountId="qa" party={party} contracts={[]} recruitment={[post]} nowMs={now} onOpenPartyChat={noop} onLeaveParty={noop} onCreateRecruitmentPost={noop}/></ScrollView>}
 {section==='Guild'&&<ScrollView contentContainerStyle={s.content}><RecruitmentListing card={{...post,postType:'guild_recruiting',guildName:'The Lanterns of Asterfall',title:'A home for wandering adventurers',guildInterestTags:['Weekly contracts']}} nowMs={now} onPress={noop}/></ScrollView>}
 <PrimaryNavigation destinations={destinations} active={active} labelFor={x=>x} onNavigate={setActive}/>
 </>}
 </View></SafeAreaView>;
}
const s=StyleSheet.create({root:{flex:1,backgroundColor:C.bg,paddingTop:Platform.OS==='android'?StatusBar.currentHeight??24:0},flex:{flex:1},qa:{backgroundColor:'#26334a'},qaLabel:{color:'#fff',fontSize:10,paddingHorizontal:10},selector:{gap:4,padding:4},pick:{minHeight:36,paddingHorizontal:12,justifyContent:'center'},content:{padding:16,gap:16}});
